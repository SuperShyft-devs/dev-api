"""Health Intelligence Engine — standalone library.

Public API::

    from modules.reports.intelligence import (
        generate_report_insights,
        enrich_camp_report_with_intelligence,
    )

    # Raw intelligence payload (profile / concerns / leadership_cards)
    payload = generate_report_insights(camp_report_json)

    # Camp-shaped enrichment (same section keys + section.intelligence)
    enriched = enrich_camp_report_with_intelligence(camp_report_json)
"""

from __future__ import annotations

from .assembly import (
    INTELLIGENCE_CAMP_SECTIONS,
    enrich_camp_report_with_intelligence,
)
from .engine import generate_report_insights

__all__ = [
    "generate_report_insights",
    "enrich_camp_report_with_intelligence",
    "INTELLIGENCE_CAMP_SECTIONS",
]
