"""Section-aware assembly: enrich Camp Report JSON with intelligence in place.

Keeps ``generate_report_insights`` generation logic unchanged. Only maps its
output onto existing camp-report section objects under an ``intelligence`` key.
"""

from __future__ import annotations

import copy
from typing import Any, Dict, Mapping, MutableMapping, Optional

from .engine import generate_report_insights

# Camp section keys that may receive an ``intelligence`` field (engine-backed).
INTELLIGENCE_CAMP_SECTIONS: frozenset[str] = frozenset(
    {
        "overall_risk_score",
        "distribution_by_physical_activity_frequency",
        "distribution_by_sleeping_hours",
        "distribution_by_oxidative_stress",
        "distribution_by_gender_by_metabolic_syndrome",
        "participation_by_age",
        "positive_wins",
    }
)

# Engine ``concerns`` keys → camp section key (1:1 narratives).
_CONCERN_TO_SECTION: Mapping[str, str] = {
    "overall_risk": "overall_risk_score",
    "physical_activity": "distribution_by_physical_activity_frequency",
    "sleep": "distribution_by_sleeping_hours",
    "oxidative_stress": "distribution_by_oxidative_stress",
    "participation": "participation_by_age",
}


def enrich_camp_report_with_intelligence(report: dict) -> dict:
    """Return a deep copy of ``report`` with section-level ``intelligence`` attached.

    Preserves exact top-level keys and each section's ``data``, ``name``, and
    ``description``. Does not add new top-level sections. Does not include
    ``profile`` or ``leadership_cards`` in the camp JSON.

    Unmapped sections (``kpis``, ``blood_and_lab_intelligence``,
    ``company_average_scores``, ``ranking``, ``meta``, …) are left unchanged.
    """
    if not isinstance(report, dict):
        raise TypeError("report must be a dict")

    enriched: Dict[str, Any] = copy.deepcopy(report)
    insights = generate_report_insights(report)
    concerns = insights.get("concerns") or {}
    if not isinstance(concerns, dict):
        concerns = {}

    for concern_key, section_key in _CONCERN_TO_SECTION.items():
        if concern_key not in concerns:
            continue
        _attach_intelligence(enriched, section_key, concerns[concern_key])

    metabolic_intel = _metabolic_intelligence(concerns)
    if metabolic_intel is not None:
        _attach_intelligence(
            enriched,
            "distribution_by_gender_by_metabolic_syndrome",
            metabolic_intel,
        )

    positives_intel = _positives_intelligence(concerns, insights)
    if positives_intel is not None:
        _attach_intelligence(enriched, "positive_wins", positives_intel)

    return enriched


def _metabolic_intelligence(concerns: Mapping[str, Any]) -> Optional[Dict[str, Any]]:
    payload: Dict[str, Any] = {}
    if "disease_risks" in concerns:
        payload["disease_risks"] = concerns["disease_risks"]
    if "disease_deep_dive" in concerns:
        payload["disease_deep_dive"] = concerns["disease_deep_dive"]
    return payload or None


def _positives_intelligence(
    concerns: Mapping[str, Any],
    insights: Mapping[str, Any],
) -> Optional[Dict[str, Any]]:
    payload: Dict[str, Any] = {}
    if "positive_highlights" in concerns:
        payload["positive_highlights"] = concerns["positive_highlights"]
    if "positives" in insights:
        payload["positives"] = insights["positives"]
    return payload or None


def _attach_intelligence(
    report: MutableMapping[str, Any],
    section_key: str,
    intelligence: Any,
) -> None:
    """Attach intelligence only if the section already exists as a dict."""
    section = report.get(section_key)
    if not isinstance(section, dict):
        return
    section["intelligence"] = intelligence
